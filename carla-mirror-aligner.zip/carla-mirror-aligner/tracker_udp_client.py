import socket
import struct
import threading

from time import sleep

import msgpack

class TrackerUDPClient(threading.Thread):
    def __init__(self, latest_value, stop_event, tracker_host="localhost", tracker_port=7000):
        super().__init__(daemon=True)
        self.latest_value = latest_value
        self.stop_event = stop_event

        self.tracker_host = tracker_host
        self.tracker_port = tracker_port

    def run(self):
        dummy_data = {
            "headPose": {"position": [0, 0, 0]},
            "viewingTargetsInfo": {"targets": []},
        }

        while not self.stop_event.is_set():
            try:
                trackersocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                trackersocket.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, True)
                trackersocket.setsockopt(socket.IPPROTO_TCP, socket.TCP_KEEPIDLE, 1)
                trackersocket.setsockopt(socket.IPPROTO_TCP, socket.TCP_KEEPINTVL, 3)
                trackersocket.setsockopt(socket.IPPROTO_TCP, socket.TCP_KEEPCNT, 5)
                trackersocket.connect((self.tracker_host, self.tracker_port))
                print("Connected to server at %s:%s" % (self.tracker_host, self.tracker_port))

            except ConnectionRefusedError:
                print("Connection refused by the server at %s:%s" % (self.tracker_host, self.tracker_port))
                print("Running without mirror functionality.")

                while True:
                    self.latest_value.set(dummy_data)
                    sleep(1.0)


            while True:
                message_id, message_size = self.readHeader(trackersocket)
                message = self.read(trackersocket, message_size)

                if message_id == 0xC0FFEE00 and len(message) > 0:

                    data = msgpack.unpackb(message, raw=False)
                    self.latest_value.set(data)

        trackersocket.close()


    def readHeader(self, sock):
        header = self.read(sock, 8)
        message_id = struct.unpack_from("I", header, 0)[0]
        message_size = struct.unpack_from("I", header, 4)[0]
        return message_id, message_size


    def read(self, sock, toread):
        buffer = bytearray(toread)
        view = memoryview(buffer)
        while toread:
            nbytes = sock.recv_into(view, toread)
            if nbytes == 0:
                raise Exception("nothing received")
            view = view[nbytes:]
            toread -= nbytes
        return buffer


        
# if __name__ == "__main__":
#     latest_value = LatestValue()
#     stop_event = threading.Event()
#     tracker_client = TrackerUDPClient(latest_value, stop_event)
#     tracker_client.start()

#     try:
#         while True:
#             data = latest_value.get()
#             if data is not None:
#                 print("Received data:", data["headPose"]["position"])
#             sleep(0.01)
#     except KeyboardInterrupt:
#         print("Stopping TrackerUDPClient...")
#         stop_event.set()
#         tracker_client.join()
#         print("Stopped.")