import threading

class LatestValue:
    def __init__(self, initial=None):
        self._lock = threading.Lock()
        self._value = initial

    def set(self, v):
        with self._lock:
            self._value = v

    def get(self):
        with self._lock:
            return self._value