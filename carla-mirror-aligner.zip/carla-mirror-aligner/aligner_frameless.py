# aligner.py
import threading
import time
import json
import numpy as np
import socket

from tracker_udp_client import TrackerUDPClient
from latest_value import LatestValue

class AlignerFrameless:
    def __init__(self, 
                 tracker_host="localhost", 
                 tracker_port=7000,
                 carla_destinations=None
                 ):
        
        self._latest_value = LatestValue()
        self._stop_event = threading.Event()

        self._tracker_udp_client = TrackerUDPClient(self._latest_value, self._stop_event, tracker_host, tracker_port)
        self._tracker_udp_client.start()

        # Initialize UDP socket for sending to CARLA
        # carla_destinations should be a list of (host, port) tuples
        # Example: [("192.168.1.10", 9870), ("192.168.1.11", 9870)]
        if carla_destinations is None:
            carla_destinations = [("localhost", 9870)]
        self.carla_destinations = carla_destinations
        self.udp_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

        self.mirror_reset_time = 2.0

        self.mirrors_dict = {
            "left": {
                "active": True,
                "recentered": False,
                "x": 0.0,
                "y": 0.0,
                "z": 0.0,
                "last_view_time": time.time(),
                "new_alignment": [0.0, 0.0, 0.0],
                "min_max_values": {
                    "x": (0.0, 0.0),
                    "y": (0.0, 0.0),
                    "z": (0.0, 0.0),
                },
            },
            "right": {
                "active": True,
                "recentered": False,
                "x": 0.0,
                "y": 0.0,
                "z": 0.0,
                "last_view_time": time.time(),
                "new_alignment": [0.0, 0.0, 0.0],
                "min_max_values": {
                    "x": (0.0, 0.0),
                    "y": (0.0, 0.0),
                    "z": (0.0, 0.0),
                },
            }
        }

    def _get_last_active_alignment(self, name):
        mirror = self.mirrors_dict[name]
        return [float(mirror["x"]), float(mirror["y"]), float(mirror["z"])]
    
    def _get_min_max_values(self, name):
        return self.mirrors_dict[name]["min_max_values"]
    
    def get_current_alignment_as_json(self):
        self._update_alignments()

        alignment_dict = {}

        for mirror, data in self.mirrors_dict.items():
            alignment_dict[mirror] = {
                "z": data["z"],
                "range": data["min_max_values"]["z"],
            }

        return json.dumps(alignment_dict)
    
    def get_zoom_percentages(self):
        self._update_alignments()

        percentages_dict = {}

        for mirror in self.mirrors_dict.keys():
            
            percentages_dict[mirror] = self._map_value(
                self.mirrors_dict[mirror]["z"],
                target_high=100,
                target_low=0,
                original_high=self._get_min_max_values(mirror)["z"][1],
                original_low=self._get_min_max_values(mirror)["z"][0],
            )

        print(percentages_dict)

        return percentages_dict
    
    def _update_alignments(self):
        self._latest_value = self._tracker_udp_client.latest_value.get()

        while self._latest_value is None:
            time.sleep(0.1)
            self._latest_value = self._tracker_udp_client.latest_value.get()

        alignment_vector = self._latest_value["headPose"]["position"]
        alignment_vector = [float(alignment_vector[0]), float(alignment_vector[1]), float(alignment_vector[2])]

        for name, mirror_data in self.mirrors_dict.items():
            if mirror_data["active"]:
                mirror_data["last_view_time"] = time.time()
                mirror_data["x"] = -alignment_vector[0]
                mirror_data["y"] = -alignment_vector[1]
                mirror_data["z"] = -alignment_vector[2]
                if not mirror_data["recentered"]:
                    
                    mirror_data["min_max_values"] = self._recenter_axes_min_max_values(name,
                        np.array([
                            mirror_data["x"],
                            mirror_data["y"],
                            mirror_data["z"],
                        ])
                    )
                    mirror_data["recentered"] = True
                    
            else:
                
                if time.time() -  mirror_data["last_view_time"] >= self.mirror_reset_time:
                    if mirror_data["recentered"]:
                        mirror_data["recentered"] = False
                        mirror_data["new_alignment"] = [mirror_data["min_max_values"][axis][1] for axis in ["x", "y", "z"]]

                    (
                        mirror_data["x"],
                        mirror_data["y"],
                        mirror_data["z"],
                    ) = self._calculate_target_alignment(name)

            mirror_data["active"] = any(
                target.get("name") == f"{name.capitalize()}Mirror"
                for target in self._latest_value["viewingTargetsInfo"]["targets"]
            )

    def _recenter_axes_min_max_values(self, name, current_alignment):
        new_min_max_values = {}
        
        for i, axis in enumerate(["x", "y", "z"]):
            min_val, max_val = self._get_min_max_values(name)[axis]
            original_range = max_val - min_val

            if axis == "z":
                offset = 0.05
                original_range = 0.30
                new_min = current_alignment[i] - original_range
                new_max = current_alignment[i] - offset
            else:
                # offset = 0
                new_min = current_alignment[i] - original_range * .5
                new_max = current_alignment[i] + original_range * .5

            new_min_max_values[axis] = (new_min, new_max)

        return new_min_max_values

    def _calculate_target_alignment(
        self, mirror, min_step_size=0.0001, max_step_size=0.001, smoothing_factor=0.1
    ):  
        new_alignment = [0.0, 0.0, 0.0] 

        max_values = {}

        for key, value in self.mirrors_dict[mirror]["min_max_values"].items():
            max_values[key] = value[1]

        current_mirror = self.mirrors_dict[mirror]

        for i, key in enumerate(["x", "y", "z"]):
            target_midpoint = max_values[key]

            distance_to_target = (target_midpoint - np.array([current_mirror["x"], current_mirror["y"], current_mirror["z"]])[i])

            step_size = np.clip(
                abs(distance_to_target) * smoothing_factor,
                min_step_size,
                max_step_size,
            )

            if abs(distance_to_target) > step_size:
                new_alignment[i] += np.sign(distance_to_target) * step_size 
            else:
                new_alignment[i] = target_midpoint 

        return new_alignment 

    def _percentage_between(self, value, low, high):
        if high == -1 or low == -1:
            return 50.0

        if high == 0 or low == 0:
            return 0.0

        if value < low:
            return 0.0
        elif value > high:
            return 100.0

        percentage = ((value - low) / (high - low)) * 100

        if np.isnan(percentage):
            return 50.0

        return percentage

    def _map_value(
        self, value, target_high, target_low=0, original_high=100, original_low=0
    ):  
        
        if value < original_low:
            return target_low
        elif value > original_high:
            return target_high

        mapped_value = target_low + (
            (value - original_low) / (original_high - original_low)
        ) * (target_high - target_low)

        if np.isnan(mapped_value):
            return 0
        
        return int(mapped_value)
    
    def _get_current_alignment_percentages(self, name):
        current_alignment = self._get_last_active_alignment(name)
        min_max_values = self._get_min_max_values(name)

        midpoint_percentage_x = self._percentage_between(
            -current_alignment[0],
            min_max_values["x"][0],
            min_max_values["x"][1],
        )

        midpoint_percentage_y = self._percentage_between(
            -current_alignment[1],
            min_max_values["y"][0],
            min_max_values["y"][1],
        )

        midpoint_percentage_z = self._percentage_between(
            current_alignment[2],
            min_max_values["z"][0],
            min_max_values["z"][1],
        )

        return {"x": midpoint_percentage_x, "y": midpoint_percentage_y, "z": midpoint_percentage_z}

    def send_pan_values_to_carla(self):
        """Send pan values to CARLA instances. Each destination gets appropriate mirror value."""
        percentages = self.get_zoom_percentages()
        
        # Convert percentages (0-100) to normalized values (0.0-1.0)
        # C++ expects: pan=0.0 (zoomed out, close), pan=1.0 (zoomed in, far)
        # Tracker gives: 0% (far), 100% (close)
        # So: far (0%) → 1.0, close (100%) → 0.0
        left_value = 1.0 - (percentages.get('left', 0) / 100.0)
        right_value = 1.0 - (percentages.get('right', 0) / 100.0)
        
        # Send to all configured CARLA destinations
        # Alternate sending left/right values to node_1/node_3
        for i, (host, port) in enumerate(self.carla_destinations):
            # Assume first destination is left mirror (node_1), second is right mirror (node_3)
            pan_value = left_value if i == 0 else right_value
            mirror_name = "left" if i == 0 else "right"
            
            # Format: "pan:0.5" (C++ expects this format)
            message = f"pan:{pan_value:.3f}"
            
            try:
                self.udp_socket.sendto(message.encode(), (host, port))
                print(f"Sent to {host}:{port} ({mirror_name}) -> {message}")
            except Exception as e:
                print(f"Error sending to {host}:{port} -> {e}")

    

if __name__ == "__main__":
    # Configure destinations for node_1 and node_3 machines
    # Replace with actual IP addresses of the machines running CARLA
    carla_nodes = [
        ("192.168.1.10", 9870),  # node_1 machine IP and port
        ("192.168.1.11", 9870),  # node_3 machine IP and port
    ]
    
    # For local testing, use localhost:
    # carla_nodes = [("localhost", 9870)]
    
    aligner = AlignerFrameless(carla_destinations=carla_nodes)
    
    while True:
        time.sleep(0.1)  # Send updates at 10 Hz
        aligner.send_pan_values_to_carla()
